package com.example.u_practicework

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
